=== Askom Virtual Agent WordPress Plugin ===
Contributors: Dominique SIMON
Tags: virtual agent
Requires at least: 3.2
Tested up to: 3.5.*
Stable tag: 1.0

A plugin that ease the integration of the Askom Virtual Agent Tag


== Description ==

[ASKOM](http://www.askom.fr/) offers a virtual agent solution destined to many types of websites. ASKOM solution provides answers to several objectives:
� Reduce calls to call center
� Reduce quantity of emails received
� Increase conversion rate in ecommerce websites
� Increase retention rate
� Answer automatically low value questions in order to delegate high value questions to humans
� Help visitors to navigate on the website


== Installation ==

1. Extract all files from the ZIP archive, making sure to keep the file structure intact.
2. Upload the `askom-virtual-agent` folder to the `/wp-content/plugins/` directory.
3. Activate the plugin through the `Plugins` menu in WordPress.
4. Go to the `Askom Virtual Agent Plugin` menu which is located under the `Settings` menu in the admin interface.
5. Enter your Askom Virtual Agent ID to activate the plugin.
6. Put the Askom Virtual Agent Widget on the place you want your calling button / virtual agent to be


== Frequently Asked Questions ==

= What is the minimal structure necessary to the plugin ? =
You only have to be sure "wp_footer()" is called on your theme, and have one Widget, that's all !

= Can i add multiple widgets of the virtual agent on a webpage ? =
No, there can be one and only one Virtual Agent Widget on a webpage


== Screenshots ==
No screenshots available


== Changelog ==

= 1.0 =
* Initial release
