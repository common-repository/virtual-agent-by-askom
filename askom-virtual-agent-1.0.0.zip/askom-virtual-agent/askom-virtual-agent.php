﻿<?php
/*
Plugin Name: Askom Virtual Agent
Plugin URI: http://www.askom.fr
Description: Askom Virtual Agent Wordpress Plugin
Version: 1.0
Author: Askom (contact@askom.fr)
Author URI: http://www.askom.fr

Copyright 2013 ASKOM (contact@askom.fr)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as 
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/


//PLUGIN SECTION ----------------------------------------------------------------------


//Plugin activation code
//	=> create ID field necessary to the plugin
register_activation_hook(__FILE__,'askomVirtualAgent_plugin_activated');
function askomVirtualAgent_plugin_activated(){
	if(!get_option('askomVirtualAgentID')) {
		//L'option n'existe pas, il faut la créer dans la base avant que l'utilisateur ne puisse la renseigner
		$askomVirtualAgentID = "";
		update_option('askomVirtualAgentID',$askomVirtualAgentID);
	}
}

//Declare domain and activate translations
$askomVirtualAgent_domain = 'askomVirtualAgentWordpressPlugin';
//load_plugin_textdomain($askomVirtualAgent_domain); 
load_plugin_textdomain( $askomVirtualAgent_domain, false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );
add_action('init', 'askomVirtualAgent_init');
function askomVirtualAgent_init() {
	if(function_exists('current_user_can') && current_user_can('manage_options'))
		add_action('admin_menu', 'askomVirtualAgent_add_settings_page');
}

//Footer insertion code
//	=> wp_footer MUST be activated on your theme if you want activate plugin / widget
add_action('wp_footer', 'askomVirtualAgent_insert');
function askomVirtualAgent_insert() {
	if(get_option('askomVirtualAgentID')) {
		//Virtual Agent Initialization Script
		//	=> needs one (and only one) widget to be displayed
		echo "<script type=\"text/javascript\">"
			."var AskomJS,AskomSt='',AskomP='".get_option('askomVirtualAgentID')."'; function AskomCA(){var u=navigator.userAgent.toLowerCase();var n=(u.match( /.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/ ) || [])[1];"
			."var p=(/msie/.test(u))&&(!/opera/.test(u))&&(n<10);AskomJS=document.createElement('script');AskomJS.id = 'Askom-script';"
			."AskomJS.async=true;AskomJS.type='text/javascript';AskomJS.src='http://askom-admin.fr/av.php?p='+AskomP;AskomJS.defer='defer';"
			."if(!p){AskomJS.onerror=function(){AskomEr();};document.body.appendChild(AskomJS);AskomJS.onload=function(){document.body.removeChild(AskomJS);};}"
			."else{AskomJS.onreadystatechange=function(){if(this.readyState=='loading'){setTimeout('AskomCL()',3000);}"
			."if(this.readyState=='loaded'){document.body.appendChild(AskomJS);AskomCL();}};}}"
			."function AskomCL(){if(AskomJS.readyState=='complete')AskomJS.onreadystatechange=null;else AskomEr();}"
			."function AskomEr(){if(AskomSt=='erreur')return false;AskomSt='erreur';var d=document.getElementById('askom');"
			."if(d!=null){d.style.backgroundImage='url(\\\"http://agent-virtuel.fr/agent_indisponible.gif\\\")';"
			."d.style.backgroundRepeat='no-repeat';d.style.backgroundPosition='center center';d.innerHTML='';}};"
			."function AskomR(f){/in/.test(document.readyState)?setTimeout('AskomR('+f+')',9):f()};AskomR(AskomCA);"
			."</script>"
			;
		
	}
}

//Admin notices
//	=> check that a valid ID is set for the Askom Virtual Agent, if not, a link to the plugin admin page is displayed
add_action('admin_notices', 'askomVirtualAgent_admin_notice');
function askomVirtualAgent_admin_notice() {
	if(!get_option('askomVirtualAgentID')) echo('<div class="error"><p><strong>'.sprintf(__('Askom Virtual Agent plugin is disabled. Please go to the <a href="%s">plugin page</a> and enter a valid account ID to enable it.' ), admin_url('options-general.php?page=askom-virtual-agent')).'</strong></p></div>');
}

//Plugin action links
//	=> put a menu item to administrate plugin
add_filter('plugin_action_links', 'askomVirtualAgent_plugin_actions', 10, 2);
function askomVirtualAgent_plugin_actions($links, $file) {
	static $this_plugin;
	if(!$this_plugin) $this_plugin = plugin_basename(__FILE__);
	if($file == $this_plugin && function_exists('admin_url')) {
		$settings_link = '<a href="'.admin_url('options-general.php?page=askom-virtual-agent').'">'.__( 'Settings', $askomVirtualAgent_domain).'</a>';
		array_unshift($links, $settings_link);
	}
	return($links);
}

//Plugin settings form
function askomVirtualAgent_add_settings_page() {
	global $askomVirtualAgent_domain;
	function askomVirtualAgent_settings_page() {
		global $askomVirtualAgent_domain; 
		?>
		<div class="wrap">
			<?php screen_icon() ?>
			<h2><?php _e('Askom Virtual Agent Plugin', $askomVirtualAgent_domain) ?></h2>
			<form method="post" action="options.php">
				<?php wp_nonce_field('update-options') ?>
				<p><label for="askomVirtualAgentID"><?php _e('Enter your Askom Virtual Agent ID', $askomVirtualAgent_domain) ?></label><br />
				<input type="text" name="askomVirtualAgentID" id="askomVirtualAgentID" size="50" maxlength="32" value="<?php echo(get_option('askomVirtualAgentID')) ?>" />
				</p><p class="submit" style="padding:0">
				<input type="hidden" name="action" value="update" />
				<input type="hidden" name="page_options" value="askomVirtualAgentID" />
				<input type="submit" name="askomVirtualAgentSubmit" id="askomVirtualAgentSubmit" value="<?php _e('Save ID', $askomVirtualAgent_domain) ?>" class="button-primary" /> 
				</p>
			</form>
		</div>
		<?php 
	}
	add_submenu_page('options-general.php', __('Askom Virtual Agent Plugin', $askomVirtualAgent_domain), __('Askom Virtual Agent Plugin', $askomVirtualAgent_domain), 'manage_options', 'askom-virtual-agent', 'askomVirtualAgent_settings_page');
}


//WIDGET SECTION ----------------------------------------------------------------------
function widget_askom_virtual_agent()
{
    register_widget("widget_askom_virtual_agent");
}
add_action("widgets_init", "widget_askom_virtual_agent");

class widget_askom_virtual_agent extends WP_widget
{
 
    function widget_askom_virtual_agent()
    {
		$options = array(
                "classname" => "widget_askom_virtual_agent",
                "description" => "Askom Virtual Agent Widget"
        );
		$this->WP_widget("askom-virtual-agent-widget", "Askom Virtual Agent Widget", $options);
    }
 
    function widget($arguments, $data)
    {
		// Extract arguments (predefined before_widget, after_widget, etc...)
		extract($arguments);
	
		// Virtual Agent Place Holder
		echo $before_widget;
		echo $before_title . "" . $after_title;
		echo "<div id='askom'></div>";
		echo $after_widget;
	}
 
    function update($content_new, $content_old)
    {
		// Empty
    }
 
    function form($data)
    {	
		// Empty    
	}
 
}

?>